// Utils.hpp
#ifndef UTILS_HPP
#define UTILS_HPP
#include <string>
#include <iostream>

namespace Utils
{
	std::string GenerateNanosecondString();

};

#endif // !UTILS_HPP

