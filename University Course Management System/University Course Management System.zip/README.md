usage
```
clang++ -stc++20 ./UniversityCourseManagementSystem.cpp -o ucms
./ucms
```